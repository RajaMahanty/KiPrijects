#include <stdio.h>
#include <string.h>
#include <windows.h>

int main(int argc, char const *argv[]) {
	FILE *fp;
	char ch1;
	int point = 0,ans1,ans2,ans3,ans4,ans5;
	char ch [20];


	fp = fopen("quize.txt","w");
	if (fp==NULL) {
		/* code */
		printf("ERROR 404");
		exit(1);
	}
		else
		{
			printf("Enter your Name: ");
			gets(ch);
			fputs(ch,fp);
			system("cls");
		}
		fclose(fp);

		fp=fopen("QUS1.txt","r");
		while (!feof(fp)) {
			/* code */
			ch1=fgetc(fp);
			printf("%c",ch1);
		}
		fclose(fp);
		printf("\t\tEnter your answer: ");
		scanf("%d",&ans1);
		if (ans1==1||ans1==2||ans1==3||ans1==4) {
			;
		} else {
			/* code */
			exit(1);
		}
		system("cls");




		fp=fopen("QUS2.txt","r");
		while (!feof(fp)) {
			/* code */
			ch1=fgetc(fp);
			printf("%c",ch1);
		}
		fclose(fp);
		printf("\t\tEnter your answer: ");
		scanf("%d",&ans2);
		if (ans2==1||ans2==2||ans2==3||ans2==4) {
			;
		} else {
			/* code */
			exit(1);
		}
		system("cls");





		fp=fopen("QUS3.txt","r");
		while (!feof(fp)) {
			/* code */
			ch1=fgetc(fp);
			printf("%c",ch1);
		}
		fclose(fp);
		printf("\t\tEnter your answer: ");
		scanf("%d",&ans3);
		if (ans3==1||ans3==2||ans3==3||ans3==4) {
			;
		} else {
			/* code */
			exit(1);
		}
		system("cls");




		fp=fopen("QUS4.txt","r");
		while (!feof(fp)) {
			/* code */
			ch1=fgetc(fp);
			printf("%c",ch1);
		}
		fclose(fp);
		printf("\t\tEnter your answer: ");
		scanf("%d",&ans4);
		if (ans4==1||ans4==2||ans4==3||ans4==4) {
			;
		} else {
			/* code */
			exit(1);
		}
		system("cls");




		fp=fopen("QUS5.txt","r");
		while (!feof(fp)) {
			/* code */
			ch1=fgetc(fp);
			printf("%c",ch1);
		}
		fclose(fp);
		printf("\t\tEnter your answer: ");
		scanf("%d",&ans5);
		if (ans5==1||ans5==2||ans5==3||ans5==4) {
			;
		} else {
			/* code */
			exit(1);
		}
		system("cls");
		fp = fopen("quizend.txt","r");

		if (ans1==1) {
			/* code */
			point++;
		}
		if (ans2==4) {
			/* code */
			point++;
		}
		if (ans3==4) {
			/* code */
			point++;
		}
		if (ans4==3) {
			/* code */
			point++;
		}
		if (ans5==1) {
			/* code */
			point++;
		}
		while (!feof(fp)) {
			/* code */
			ch1=fgetc(fp);
			printf("%c",ch1);
		}
		fclose(fp);
		printf("YOUER POINT : %d ",++point);
		if (point==5) {
			/* code */
			printf("\nExcellent work");
		}
		if(point==4)
		{
				printf("\nGreat work");
		}
		if (point==3) {
			/* code */
			printf("\ngood work");
		}
		if (point==2) {
			/* code */
			printf("\nSatisfactory work");
		}
		if (point==1) {
			/* code */
			printf("Try next time");
		}

	return 0;
}
